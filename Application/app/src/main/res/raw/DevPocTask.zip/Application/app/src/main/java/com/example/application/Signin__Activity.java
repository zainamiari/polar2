package com.example.application;

import androidx.appcompat.app.AppCompatActivity;

public abstract class Signin__Activity extends AppCompatActivity {
}
